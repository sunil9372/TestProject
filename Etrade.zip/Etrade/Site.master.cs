﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class SiteMaster : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["user"] == null || Session["user"] == "")
        {

            Response.Redirect("Login.aspx");
        }
        else
        {
            lblUser.Text = "Logged in as " + "<b>" + Session["user"].ToString() + "</b>";
            if (Convert.ToInt32(Session["Access"]) == 0)
            {
                //Menu NavigationMenu1 = new Menu();
                //NavigationMenu.HasAttribute  
                //NavigationMenu.FindItem("SurveyAdmin.aspx").Enabled = false;     
                //NavigationMenu.Items[1].Enabled = false;
                //NavigationMenu.Items[2].Enabled = false;
            }

        }
    }
    protected void lnkLogout_Click(object sender, EventArgs e)
    {
        Session.Remove("user"); 
    }
}
