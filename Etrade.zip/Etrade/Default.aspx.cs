﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration; 

public partial class _Default : System.Web.UI.Page
{
    string conStr = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString.ToString();    
    protected void Page_Load(object sender, EventArgs e)
    {
        SqlConnection sqlCon = new SqlConnection(conStr);
        sqlCon.Open();
        SqlCommand cmd = new SqlCommand("select categoryid,categoryname from category", sqlCon);
        SqlDataReader dr;
        dr = cmd.ExecuteReader();
        while (dr.Read())
        {
            HyperLink lnk = new HyperLink();
            lnk.Text = dr[1].ToString();
            lnk.ID = dr[0].ToString();
            lnk.NavigateUrl = "~/frmProductsDisplay.aspx?id=" + lnk.ID;
            PlaceHolder1.Controls.Add(lnk);
            PlaceHolder1.Controls.Add(new LiteralControl("<br />"));
        }
        sqlCon.Close();
        if (Session["user"] == null || Session["user"] == "")
        {

            Response.Redirect("Login.aspx");
        }
    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        
    }
}
