﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
   

public partial class Login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnLogin_Click(object sender, EventArgs e)
    {

        if (Session["Captcha"].ToString() == TextBox1.Text)
        {
           // lblMsg.Text = " System identified you as a human";
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString.ToString());
            con.Open();
            SqlCommand cmd = new SqlCommand("select username,password from logins", con);
            SqlDataReader dr;
            dr = cmd.ExecuteReader();
            while (dr.Read())
            {

                if (txtUserName.Text == dr[0].ToString())
                {

                    if (txtPassword.Text == dr[1].ToString())
                    {
                        //make a session for the user to get control on all pages
                        Session["user"] = txtUserName.Text.ToString();
                        //Session["Access"] = dr[2].ToString(); 
                        Response.Redirect("frmDisplay.aspx");
                        //write a code to audit each logins
                    }
                    lblMsg.Visible = true;
                    lblMsg.Text = "Invalid Password";
                }
                else
                {
                    lblMsg.Visible = true;
                    lblMsg.Text = "Invalid Username";
                }
            }
            con.Close(); 
        }
        else
        {
            lblMsg.Text = "Please try again";
            TextBox1.Text = "";
        }
        

    }
}