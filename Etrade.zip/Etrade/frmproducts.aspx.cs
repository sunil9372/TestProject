﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;  
using System.Collections;
using System.Configuration;

public partial class frmproducts : System.Web.UI.Page
{
    string conStr = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString.ToString();    
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            bind();

            bindProducts();


        }
    }

    public void bind()
    {
        SqlConnection ConSQL = new SqlConnection(conStr);
        ConSQL.Open();
        SqlDataAdapter da = new SqlDataAdapter("select categoryid,categoryname from category", ConSQL);
        DataSet ds = new DataSet();
        da.Fill(ds, "Result");
        ddlCategory.DataSource = ds.Tables[0];
        ddlCategory.DataTextField = "categoryname";
        ddlCategory.DataValueField = "categoryid";
        ddlCategory.DataBind();
        ConSQL.Close();
    }

    public void bindProducts()
    {
        SqlConnection ConSQL = new SqlConnection(conStr);
        ConSQL.Open();
        SqlDataAdapter da = new SqlDataAdapter("select * from products", ConSQL);
        DataSet ds = new DataSet();
        da.Fill(ds, "Products");
        GridView2.DataSource = ds.Tables[0];
        GridView2.DataBind();
        ConSQL.Close();
    }

    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView2.PageIndex = e.NewPageIndex;
        bindProducts(); 
    }
    protected void GridView1_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        GridView2.EditIndex = -1;
        bindProducts(); 
    }
    protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        GridViewRow row = (GridViewRow)GridView2.Rows[e.RowIndex];
        Label lbl = (Label)row.FindControl("lblid");
        SqlConnection ConSQL = new SqlConnection(conStr);
        ConSQL.Open();
        SqlCommand cmd = new SqlCommand("delete  products where partid=" + lbl.Text + "", ConSQL);
        cmd.ExecuteNonQuery();
        ConSQL.Close();
        bindProducts();  
    }
    protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        GridViewRow row = (GridViewRow)GridView2.Rows[e.RowIndex];
        Label lbl = (Label)row.FindControl("lblId");
        TextBox txtPartNum = (TextBox)row.FindControl("Textbox1");
        TextBox txtPartDescr = (TextBox)row.FindControl("Textbox2");
        TextBox txtUnitPrice = (TextBox)row.FindControl("Textbox3");
        TextBox txtQty = (TextBox)row.FindControl("Textbox4");
        TextBox txtMinQty = (TextBox)row.FindControl("Textbox5");
        //TextBox textmarks = (TextBox)row.FindControl("textbox2");  
        DropDownList ddlCId = (DropDownList)row.FindControl("cmbCat");
        GridView2.EditIndex = -1;
        SqlConnection ConSQL = new SqlConnection(conStr);
        ConSQL.Open();
        SqlCommand cmd = new SqlCommand("update products set partno='" + txtPartNum.Text + "',partDescription='" + txtPartDescr.Text + "',unitprice='" + txtUnitPrice.Text + "',qty = '"+ txtQty.Text  +"',minQty='"+ txtMinQty.Text  +"' ,categoryid ='" + ddlCId.SelectedValue.ToString() + "'  where partid=" + lbl.Text + "", ConSQL);
        cmd.ExecuteNonQuery();
        ConSQL.Close();
        bindProducts();                    
    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
    {
        GridView2.EditIndex = e.NewEditIndex;
        bindProducts(); 
    }
    protected void btnProdAdd_Click(object sender, EventArgs e)
    {
        SqlConnection sqlCon = new SqlConnection(conStr);
        sqlCon.Open();
        SqlCommand cmd = new SqlCommand("insert into products(partno,partdescription,unitprice,qty,minQty,categoryid) values('" + txtPartNo.Text.ToString() + "','" + txtPartDesc.Text.ToString() + "','" + txtUnitprice.Text.ToString() + "','" + txtPQty.Text.ToString() + "','" + txtMinQty.Text.ToString() + "','" + ddlCategory.SelectedValue.ToString() + "') ", sqlCon);
        cmd.ExecuteNonQuery();
        bindProducts();
        txtPartNo.Text = ""; 
        txtPartDesc.Text = "";
        txtUnitprice.Text = "";
        txtPQty.Text = "";
        txtMinQty.Text = ""; 
        sqlCon.Close();  
    }
}