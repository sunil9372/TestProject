﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Data.Common;   

public partial class frmProductsDisplay : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string strId = Request.QueryString["id"];

        SqlConnection sqlCon = new SqlConnection(ConfigurationManager.ConnectionStrings["connectionString"].ConnectionString);
        sqlCon.Open();
        SqlDataAdapter da = new SqlDataAdapter("SELECT Products.PartId, Products.PartNo, Products.PartDescription, Products.UnitPrice, Products.Qty, Products.MinQty, Category.CategoryName " +
        "FROM Category INNER JOIN Products ON Category.CategoryId = Products.CategoryId WHERE Category.CategoryId = " + strId + "", sqlCon);
        DataSet ds = new DataSet();
        da.Fill(ds, "products");
        GridView1.DataSource = ds.Tables[0];
        GridView1.DataBind();
        sqlCon.Close();  
    }
}