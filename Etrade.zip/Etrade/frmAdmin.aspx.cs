﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration; 


public partial class frmAdmin : System.Web.UI.Page
{
    string conStr = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString.ToString();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            //GridView1.Visible = false;
            bind();

        }  

    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        GridViewRow row = (GridViewRow)GridView1.Rows[e.RowIndex];
        Label lbl = (Label)row.FindControl("lblId");
        TextBox txtName = (TextBox)row.FindControl("Textbox1");
        //TextBox textmarks = (TextBox)row.FindControl("textbox2");          
        GridView1.EditIndex = -1;
        SqlConnection ConSQL = new SqlConnection(conStr);
        ConSQL.Open();
        SqlCommand cmd = new SqlCommand("update  category set categoryname='" + txtName.Text + "'  where categoryid=" + lbl.Text + "", ConSQL);
        cmd.ExecuteNonQuery();
        ConSQL.Close();
        bind();          
    }
    protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
    {
        GridView1.EditIndex = e.NewEditIndex;
        bind(); 
    }
    protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        GridViewRow row = (GridViewRow)GridView1.Rows[e.RowIndex];
        Label lbl = (Label)row.FindControl("lblid");
        SqlConnection ConSQL = new SqlConnection(conStr);
        ConSQL.Open();
        SqlCommand cmd = new SqlCommand("delete  category where categoryid=" + lbl.Text + "", ConSQL);
        cmd.ExecuteNonQuery();
        ConSQL.Close();
        bind();  
    }
    protected void GridView1_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        GridView1.EditIndex = -1;
        bind(); 
    }
    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView1.PageIndex = e.NewPageIndex;
        bind(); 
    }

    public void bind()
    {
        SqlConnection ConSQL = new SqlConnection(conStr);
        ConSQL.Open();
        SqlDataAdapter da = new SqlDataAdapter("select categoryid,categoryname from category", ConSQL);
        DataSet ds = new DataSet();
        da.Fill(ds, "dep");

        //if (ds.Tables[0].Rows.Count > 0 )
        //{
            GridView1.DataSource = ds.Tables[0];
            GridView1.DataBind(); 
        //}
        //else
        //{
        //    ds.Tables[0].Rows.Add(ds.Tables[0].NewRow());   
        //    GridView1.DataSource = ds.Tables[0];
        //    GridView1.DataBind(); 

        //    int TotalColumns = GridView1.Rows[0].Cells.Count;
        //    GridView1.Rows[0].Cells.Clear();
        //    GridView1.Rows[0].Cells.Add(new TableCell());
        //    GridView1.Rows[0].Cells[0].ColumnSpan = TotalColumns;
        //    GridView1.Rows[0].Cells[0].Text = "No Record Found";
        //}
        ConSQL.Close();

        
    }

}