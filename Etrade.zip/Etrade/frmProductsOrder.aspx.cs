﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Data.Common;   

public partial class frmProductsOrder : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string strId = Request.QueryString["PartId"];

        SqlConnection sqlCon = new SqlConnection(ConfigurationManager.ConnectionStrings["connectionString"].ConnectionString);
        sqlCon.Open();
        SqlCommand cmd = new SqlCommand("select PartNo,PartDescription,UnitPrice,MinQty from Products where PartId = '"+ strId  +"'", sqlCon);
        SqlDataReader dr;
        dr = cmd.ExecuteReader();
        while (dr.Read() )
        {
            lblPartNo.Text = dr[0].ToString() ;
            lblPartDescr.Text = dr[1].ToString();
            lblPrice.Text = dr[2].ToString();
            lblMinQty.Text = dr[3].ToString();  
        }
        sqlCon.Close();  
    }
}