﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Collections;
using System.Configuration;

public partial class frmProductSearch : System.Web.UI.Page
{
    string conStr = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString.ToString();    
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            bind();
        }
    }
    protected void chkPartNo_CheckedChanged(object sender, EventArgs e)
    {
        //if (chkPartNo.Checked == true  )
        //{
        //    txtPartNo.Enabled = true; 
        //}
        //else
        //{
        //    txtPartNo.Enabled = false; 
        //}
    }
    protected void chkCat_CheckedChanged(object sender, EventArgs e)
    {
        //if (chkCat.Checked == true )
        //{
        //    ddlCategory.Enabled = true;  
        //}
        //else
        //{
        //    ddlCategory.Enabled = false;
        //}
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        //string str;
        //str = "";
        if (chkPartNo.Checked == true && chkCat.Checked == true )
        {
            SqlConnection sqlCon = new SqlConnection(ConfigurationManager.ConnectionStrings["connectionString"].ConnectionString);
            sqlCon.Open();
            SqlDataAdapter da = new SqlDataAdapter("SELECT Products.PartId, Products.PartNo, Products.PartDescription, Products.UnitPrice, Products.Qty, Products.MinQty, Category.CategoryName, " +
            "Category.CategoryId FROM Category INNER JOIN Products ON Category.CategoryId = Products.CategoryId and Products.partno like '%" + txtPartNo.Text + "%'  and Category.categoryid ='" + ddlCategory.SelectedValue.ToString() + "'", sqlCon);
            DataSet ds = new DataSet();
            da.Fill(ds, "products");
            GridView1.DataSource = ds.Tables[0];
            GridView1.DataBind();
            sqlCon.Close();  
        }
        if (chkPartNo.Checked == true)
        {
            SqlConnection sqlCon = new SqlConnection(ConfigurationManager.ConnectionStrings["connectionString"].ConnectionString);
            sqlCon.Open();
            SqlDataAdapter da = new SqlDataAdapter("SELECT Products.PartId, Products.PartNo, Products.PartDescription, Products.UnitPrice, Products.Qty, Products.MinQty, Category.CategoryName, " +
            "Category.CategoryId FROM Category INNER JOIN Products ON Category.CategoryId = Products.CategoryId and Products.partno like '%" + txtPartNo.Text + "%' ", sqlCon);
            DataSet ds = new DataSet();
            da.Fill(ds, "products");
            GridView1.DataSource = ds.Tables[0];
            GridView1.DataBind();
            sqlCon.Close();  
        }
        if (chkCat.Checked == true)
        {
                        SqlConnection sqlCon = new SqlConnection(ConfigurationManager.ConnectionStrings["connectionString"].ConnectionString);
            sqlCon.Open();
            SqlDataAdapter da = new SqlDataAdapter("SELECT Products.PartId, Products.PartNo, Products.PartDescription, Products.UnitPrice, Products.Qty, Products.MinQty, Category.CategoryName, " +
            "Category.CategoryId FROM Category INNER JOIN Products ON Category.CategoryId = Products.CategoryId and Category.categoryid ='" + ddlCategory.SelectedValue.ToString() + "'", sqlCon);
            DataSet ds = new DataSet();
            da.Fill(ds, "products");
            GridView1.DataSource = ds.Tables[0];
            GridView1.DataBind();
            sqlCon.Close();
        }

    }
    public void bind()
    {
        SqlConnection ConSQL = new SqlConnection(conStr);
        ConSQL.Open();
        SqlDataAdapter da = new SqlDataAdapter("select categoryid,categoryname from category", ConSQL);
        DataSet ds = new DataSet();
        da.Fill(ds, "Result");
        ddlCategory.DataSource = ds.Tables[0];
        ddlCategory.DataTextField = "categoryname";
        ddlCategory.DataValueField = "categoryid";
        ddlCategory.DataBind();
        ConSQL.Close();
    }
}